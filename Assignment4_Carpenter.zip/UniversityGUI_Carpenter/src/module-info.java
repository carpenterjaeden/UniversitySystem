module University_Carpenter {
	requires junit;
	requires org.junit.jupiter.api;
}