package org.university.software;

import java.util.ArrayList;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

import javax.swing.*;

import org.university.hardware.*;
import org.university.people.*;


public class UniversityGUI extends JFrame{
	
	
	private JMenuBar menuBar;		//the horizontal container
//NAMES FOR ALL MENUS
	private JMenu fileMenu;
	private JMenu studentsMenu;
	private JMenu administratorsMenu;
	
	private University u1;

//OUTPUT WINDOWS
	private JTextArea outputArea;    
	private JFrame scrollFrame;
	private JScrollPane scrollPane;
	
//	scrollInfo.setTitle("University Info");
//	scrollInfo.setLayout(new FlowLayout());
//	outputArea.setEditable(false);
//	scrollPane = new JScrollPane(outputArea);
    
	 
//NAMES FOR ALL ITEMS
	private JMenuItem fileSave;
	private JMenuItem fileLoad;
	private JMenuItem fileExit;
	
	private JMenuItem studentsAddCourse;
	private JMenuItem studentsDropCourse;
	private JMenuItem studentsPrintSchedule;
	
	private JMenuItem adminsPrintAllInfo;
	private JMenuItem adminsNewCampusCourse;
	private JMenuItem adminsNewOnlineCourse;
	private JMenuItem adminsNewDepartment;
	private JMenuItem adminsAssignCourseClassroom;
	private JMenuItem adminsAssignCourseProfessor;
//END NAMES FOR ALL ITEMS
	
	public UniversityGUI(String windowTitle, University uni) 
	{
		super(windowTitle);
		

		setSize(300, 100);
		
		setLayout(new FlowLayout(FlowLayout.LEFT));
		
		add(new JLabel("<HTML><center>Welcome to the University." +
				"<BR>Choose an action from the above menus.</center></HTML>"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		buildGUI();	
		setVisible(true);
		this.u1 = uni;
	}
	
	
	public void buildGUI() 
	{
//INITIALIZE MENU BAR HERE
		menuBar = new JMenuBar();
		
// INITIALIZE MENUS HERE
		fileMenu = new JMenu("File");
		studentsMenu = new JMenu("Students");
		administratorsMenu = new JMenu("Administrators");
		
//INITIALIZE MENU BUTTONS HERE
		fileSave = new JMenuItem("Save");
		fileLoad = new JMenuItem("Load");
		fileExit = new JMenuItem("Exit");
		
		studentsAddCourse = new JMenuItem("Add Course");
		studentsDropCourse = new JMenuItem("Drop Course");
		studentsPrintSchedule = new JMenuItem("Print Schedule");
		
		adminsPrintAllInfo = new JMenuItem("Print All Info");
		adminsNewCampusCourse = new JMenuItem("New Campus Course");
		adminsNewOnlineCourse = new JMenuItem("New Online Course");
		adminsNewDepartment = new JMenuItem("New Department");
		adminsAssignCourseClassroom = new JMenuItem("Assign Course Classroom");
		adminsAssignCourseProfessor = new JMenuItem("Assign Course Professor");
		
//INITIALIZE WHAT BUTTONS DO HERE
		fileSave.addActionListener(new MenuListener());
		fileLoad.addActionListener(new MenuListener());
		fileExit.addActionListener(new MenuListener());
		
		studentsAddCourse.addActionListener(new MenuListener());
		studentsDropCourse.addActionListener(new MenuListener());
		studentsPrintSchedule.addActionListener(new MenuListener());
		
		adminsPrintAllInfo.addActionListener(new MenuListener());
		adminsNewCampusCourse.addActionListener(new MenuListener());
		adminsNewOnlineCourse.addActionListener(new MenuListener());
		adminsNewDepartment.addActionListener(new MenuListener());
		adminsAssignCourseClassroom.addActionListener(new MenuListener());
		adminsAssignCourseProfessor.addActionListener(new MenuListener());
//ADD BUTTONS TO MENU HERE
		fileMenu.add(fileSave);
		fileMenu.add(fileLoad);
		fileMenu.add(fileExit);
		
		studentsMenu.add(studentsAddCourse);
		studentsMenu.add(studentsDropCourse);
		studentsMenu.add(studentsPrintSchedule);
		
		administratorsMenu.add(adminsPrintAllInfo);
		administratorsMenu.add(adminsNewCampusCourse);
		administratorsMenu.add(adminsNewOnlineCourse);
		administratorsMenu.add(adminsNewDepartment);
		administratorsMenu.add(adminsAssignCourseClassroom);
		administratorsMenu.add(adminsAssignCourseProfessor);
//ADD MENUS TO MENUBAR HERE		
		menuBar.add(fileMenu);
		menuBar.add(studentsMenu);		
		menuBar.add(administratorsMenu);
//SET MENU BAR HERE?	
		setJMenuBar(menuBar);
	}
	
//MENU LISTENER CLASS FOR MAKING THE MENU WORK
	private class MenuListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) //this is the method MenuListener must implement, as it comes from the ActionListener interface.
		{
			JMenuItem source = (JMenuItem)(e.getSource());
//ALL OF THE ACTIONS FOR THE BUTTONS
			if (source.equals(fileSave))
			{
				u1.saveData(u1);
			}
			else if (source.equals(fileLoad))
			{
				u1 = u1.loadData();
			}
			else if (source.equals(fileExit))
			{
				setVisible(false);
				dispose();
			}
//ELSE IF ADD COURSE-----------------------------------------
			else if (source.equals(studentsAddCourse)) {
				//CREATE FIELDS
				  JTextField sName = new JTextField(5);
			      JTextField dName = new JTextField(5);
			      JTextField cNum = new JTextField(5);
			      Boolean checkFail = false;
			      Boolean checkHelp = false;
//ADD FIELDS TO LIST			      
			      Object[] fields = {
			    		  "Student Name:", sName,
			    		  "Department:", dName,
			    		  "Course #:", cNum
			      };
//OUTPUT THE FIELDS
			      JOptionPane.showConfirmDialog(null, fields,"Add Course"
			    		  ,JOptionPane.OK_CANCEL_OPTION);
//CHECK FOR EMPTY ENTRIES			      
				for (Object check : fields) {
					if (check instanceof JTextField) {
					if (((JTextField) check).getText().length() == 0) {
						JOptionPane.showMessageDialog(null, 
								"User Input cannot be empty", 
								"Error Adding Course to Schedule", 
								JOptionPane.ERROR_MESSAGE);
						checkFail = true;
						break;
						
					}
					}
				}
//CHECK FOR EXISTING STUDENT
				if (checkFail == false) {
					for (Department check : u1.getDepartmentList()) {
						for (Student check1 : check.getStudentList()) {
							if (check1.getName().equalsIgnoreCase(sName.getText())) {
								checkHelp=true;
								break;
							}
						}
					}
					if (!checkHelp) {
						JOptionPane.showMessageDialog(null,  
								"Student "+sName.getText()
								+" doesn't exist",
								"Error",
								JOptionPane.PLAIN_MESSAGE);
						checkFail = true;
					}
					checkHelp = false;
				}
//CHECK FOR EXISTING DEPARTMENT
				if (checkFail == false) {
					for (Department check : u1.getDepartmentList()) {
						if (dName.getText().equalsIgnoreCase(check.getDepartmentName())) {
							checkHelp = true;
							break;
						}
					}
					if (!checkHelp) {
						JOptionPane.showMessageDialog(null,  
								"Department "+dName.getText()
								+" doesn't exist",
								"Error",
								JOptionPane.PLAIN_MESSAGE);
						checkFail = true;
					}
					checkHelp = false;
				}
//CHECK FOR EXISTING Course
				if (checkFail == false) {
					for (Department check : u1.getDepartmentList()) {
						if (dName.getText().equalsIgnoreCase(check.getDepartmentName())) {
							for (Course check1 : check.getCampusCourseList()) {
								if (check1.getCourseNumber()==Integer.parseInt(cNum.getText())) {
							checkHelp = true;
							break;
								}
							}
							for (Course check1 : check.getOnlineCourseList()) {
								if (check1.getCourseNumber()==Integer.parseInt(cNum.getText())) {
							checkHelp = true;
							break;
								}
							}
						}
					}
					if (!checkHelp) {
						JOptionPane.showMessageDialog(null,  
								"Course: "+dName.getText().toUpperCase()
								+cNum.getText()
								+" doesn't exist",
								"Error",
								JOptionPane.PLAIN_MESSAGE);
						checkFail = true;
					}
					checkHelp = false;
				}
//CHECK CONFLICTING TIME SLOT IF THERE ARE TOO MANY STUDENTS AND IF THEY HAVE PROPER CREDITS
				Course forPrint = null;
				if (checkFail == false) {
					ByteArrayOutputStream out1 = new ByteArrayOutputStream();
					PrintStream out = new PrintStream(out1);
					PrintStream old = System.out;
					System.setOut(out);
					for (Department check : u1.getDepartmentList()) {
						if (dName.getText().equalsIgnoreCase(check.getDepartmentName())) {
							for (Department check3 : u1.getDepartmentList()) {
							for (Student check1 : check3.getStudentList()) {
								if (check1.getName().equalsIgnoreCase(sName.getText())) {
									for (CampusCourse check2 : check.getCampusCourseList()) {
										if (check2.getCourseNumber()==Integer.parseInt(cNum.getText())) {
											check1.addCourse(check2);
											if (out1.toString().length()!=0) {
												JOptionPane.showMessageDialog(null,  
														out1.toString(),
														"Error",
														JOptionPane.PLAIN_MESSAGE);
												System.setOut(old);
												return;
											}
											else {
												forPrint = check2;
												System.setOut(old);
												checkFail=false;
											}
											}
										
										}
									for (OnlineCourse check2 : check.getOnlineCourseList()) {
										if (check2.getCourseNumber()==Integer.parseInt(cNum.getText())) {
											check1.addCourse(check2);
											if (out1.toString().length()!=0) {
												JOptionPane.showMessageDialog(null,  
														out1.toString(),
														"Error",
														JOptionPane.PLAIN_MESSAGE);
												System.setOut(old);
												return;
											}
											else {
												forPrint = check2;
												System.setOut(old);
												checkFail=false;
											}
											}
										}
									}
								}
							}
							}
						}
					}
		
//ADD COURSE
				if (checkFail == false) {
					JOptionPane.showMessageDialog(null,  
							"Success you have added "+forPrint.getName(),
							"Success",
							JOptionPane.PLAIN_MESSAGE);
				}
			}
//ELSE IF DROP COURSE-----------------------------------------
			else if (source.equals(studentsDropCourse)) {
				//CREATE FIELDS
				  JTextField sName = new JTextField(5);
			      JTextField dName = new JTextField(5);
			      JTextField cNum = new JTextField(5);
			      Boolean checkFail = false;
			      Boolean checkHelp = false;
//ADD FIELDS TO LIST			      
			      Object[] fields = {
			    		  "Student Name:", sName,
			    		  "Department:", dName,
			    		  "Course #:", cNum
			      };
//OUTPUT THE FIELDS
			      JOptionPane.showConfirmDialog(null, fields,"Drop Course"
			    		  ,JOptionPane.OK_CANCEL_OPTION);
//CHECK FOR EMPTY ENTRIES			      
				for (Object check : fields) {
					if (check instanceof JTextField) {
					if (((JTextField) check).getText().length() == 0) {
						JOptionPane.showMessageDialog(null, 
								"User Input cannot be empty", 
								"Error", 
								JOptionPane.ERROR_MESSAGE);
						checkFail = true;
						break;
						
					}
					}
				}
//CHECK FOR EXISTING STUDENT
				if (checkFail == false) {
					for (Department check : u1.getDepartmentList()) {
						for (Student check1 : check.getStudentList()) {
							if (check1.getName().equalsIgnoreCase(sName.getText())) {
								checkHelp=true;
								break;
							}
						}
					}
					if (!checkHelp) {
						JOptionPane.showMessageDialog(null,  
								"Student "+sName.getText()
								+" doesn't exist",
								"Error",
								JOptionPane.PLAIN_MESSAGE);
						checkFail = true;
					}
					checkHelp = false;
				}
//CHECK FOR EXISTING DEPARTMENT
				if (checkFail == false) {
					for (Department check : u1.getDepartmentList()) {
						if (dName.getText().equalsIgnoreCase(check.getDepartmentName())) {
							checkHelp = true;
							break;
						}
					}
					if (!checkHelp) {
						JOptionPane.showMessageDialog(null,  
								"Department "+dName.getText()
								+" doesn't exist",
								"Error",
								JOptionPane.PLAIN_MESSAGE);
						checkFail = true;
					}
					checkHelp = false;
				}
//CHECK FOR EXISTING Course
				if (checkFail == false) {
					for (Department check : u1.getDepartmentList()) {
						if (dName.getText().equalsIgnoreCase(check.getDepartmentName())) {
							for (Course check1 : check.getCampusCourseList()) {
								if (check1.getCourseNumber()==Integer.parseInt(cNum.getText())) {
							checkHelp = true;
							break;
								}
							}
							for (Course check1 : check.getOnlineCourseList()) {
								if (check1.getCourseNumber()==Integer.parseInt(cNum.getText())) {
							checkHelp = true;
							break;
								}
							}
						}
					}
					if (!checkHelp) {
						JOptionPane.showMessageDialog(null,  
								"Course: "+dName.getText().toUpperCase()
								+cNum.getText()
								+" doesn't exist",
								"Error",
								JOptionPane.PLAIN_MESSAGE);
						checkFail = true;
					}
					checkHelp = false;
				}
//CHECK CONFLICTS
				Course forPrint = null;
				if (checkFail == false) {
					ByteArrayOutputStream out1 = new ByteArrayOutputStream();
					PrintStream out = new PrintStream(out1);
					PrintStream old = System.out;
					System.setOut(out);
					for (Department check : u1.getDepartmentList()) {
						if (dName.getText().equalsIgnoreCase(check.getDepartmentName())) {
							for (Department check3 : u1.getDepartmentList()) {
							for (Student check1 : check3.getStudentList()) {
								if (check1.getName().equalsIgnoreCase(sName.getText())) {
									for (CampusCourse check2 : check.getCampusCourseList()) {
										if (check2.getCourseNumber()==Integer.parseInt(cNum.getText())) {
											check1.dropCourse(check2);
											if (out1.toString().length()!=0) {
												JOptionPane.showMessageDialog(null,  
														out1.toString(),
														"Error",
														JOptionPane.PLAIN_MESSAGE);
												System.setOut(old);
												return;
											}
											else {
												forPrint = check2;
												System.setOut(old);
												checkFail=false;
											}
											}
										
										}
									for (OnlineCourse check2 : check.getOnlineCourseList()) {
										if (check2.getCourseNumber()==Integer.parseInt(cNum.getText())) {
											check1.dropCourse(check2);
											if (out1.toString().length()!=0) {
												JOptionPane.showMessageDialog(null,  
														out1.toString(),
														"Error",
														JOptionPane.PLAIN_MESSAGE);
												System.setOut(old);
												return;
											}
											else {
												forPrint = check2;
												System.setOut(old);
												checkFail=false;
											}
											}
										}
									}
								}
							}
							}
						}
					}
		
//ADD COURSE
				if (checkFail == false) {
					JOptionPane.showMessageDialog(null,  
							"Success you have dropped "+forPrint.getName(),
							"Success",
							JOptionPane.PLAIN_MESSAGE);
				}
			}
//ELSE IF PRINTALL-------------------------------------------
			else if (source.equals(adminsPrintAllInfo)) {
				outputArea = new JTextArea(25,40);    
				scrollFrame = new JFrame();
				scrollFrame.setSize(500, 500);
				scrollPane = new JScrollPane(outputArea);
				scrollFrame.setTitle("University Info");
				scrollFrame.setLayout(new FlowLayout());
				outputArea.setEditable(false);
//				outputArea.setLineWrap(true);
				
				

				ByteArrayOutputStream out1 = new ByteArrayOutputStream();
				PrintStream out = new PrintStream(out1);
				PrintStream old = System.out;
				System.setOut(out);
				u1.printAll();
				System.out.flush();
				System.setOut(old);

				
				outputArea.setText(out1.toString());

				scrollFrame.add(scrollPane);
				
				scrollFrame.setVisible(true);
			}
//ELSE IF PRINT SCHEDULE----------------------------------
			else if (source.equals(studentsPrintSchedule)) {
				//CREATE FIELDS
				  JTextField sName = new JTextField(5);

			      Boolean checkFail = false;
			      Boolean checkHelp = false;

//ADD FIELDS TO LIST			      
			      Object[] fields = {
			    		  "Student Name:", sName
			      };
//OUTPUT THE FIELDS
			      JOptionPane.showConfirmDialog(null, fields,"Print Student Schedule"
			    		  ,JOptionPane.OK_CANCEL_OPTION);
//CHECK FOR EMPTY ENTRIES			      
				for (Object check : fields) {
					if (check instanceof JTextField) {
					if (((JTextField) check).getText().length() == 0) {
						JOptionPane.showMessageDialog(null, 
								"User Input cannot be empty", 
								"Error", 
								JOptionPane.ERROR_MESSAGE);
						checkFail = true;
						break;
						
					}
					}
				}
//CHECK FOR EXISTING STUDENT
				if (checkFail == false) {
					for (Department check : u1.getDepartmentList()) {
						for (Student check1 : check.getStudentList()) {
							if (check1.getName().equalsIgnoreCase(sName.getText())) {
								checkHelp=true;
								break;
							}
						}
					}
					if (!checkHelp) {
						JOptionPane.showMessageDialog(null,  
								"Student "+sName.getText()
								+" doesn't exist",
								"Error",
								JOptionPane.PLAIN_MESSAGE);
						checkFail = true;
					}
					checkHelp = false;
				}
//PRINT SCHEDULE
				
			if (checkFail == false) {	

				ByteArrayOutputStream out1 = new ByteArrayOutputStream();
				PrintStream out = new PrintStream(out1);
				PrintStream old = System.out;
				System.setOut(out);
				for (Department check : u1.getDepartmentList()) {
					for (Student check1 : check.getStudentList()) {
						if (check1.getName().equalsIgnoreCase(sName.getText())) {
							check1.printSchedule();
							System.out.flush();
							System.setOut(old);

							
							JOptionPane.showMessageDialog(null, 
									out1.toString(), 
									"Student "+check1.getName()+"'s Schedule", 
									JOptionPane.PLAIN_MESSAGE);
						}
					}
				}
				System.setOut(old);
				
			}
				
				}
//ELSE ADD CAMPUS COURSE--------------------------------------------------	
			else if (source.equals(adminsNewCampusCourse)) {
//CREATE FIELDS
				  JTextField cName = new JTextField(5);
			      JTextField dName = new JTextField(5);
			      JTextField cNum = new JTextField(5);
			      JTextField maxStudents = new JTextField(5);
			      JTextField credits = new JTextField(5);
			      JTextField schedule = new JTextField(5);
			      Boolean checkFail = false;
			      Boolean checkHelp = false;
//ADD FIELDS TO LIST			      
			      Object[] fields = {
			    		  "Course Name:", cName,
			    		  "Department:", dName,
			    		  "Course #:", cNum,
			    		  "Max Students:", maxStudents,
			    		  "Credits:", credits,
			    		  "Schedule:", schedule
			      };
//OUTPUT THE FIELDS
			      JOptionPane.showConfirmDialog(null, fields,"Create New Campus Course"
			    		  ,JOptionPane.OK_CANCEL_OPTION);
//CHECK FOR EMPTY ENTRIES			      
				for (Object check : fields) {
					if (check instanceof JTextField) {
					if (((JTextField) check).getText().length() == 0) {
						JOptionPane.showMessageDialog(null, 
								"User Input cannot be empty", 
								"Error Creating Campus Course", 
								JOptionPane.ERROR_MESSAGE);
						checkFail = true;
						break;
						
					}
					}
				}
//CHECK FOR EXISTING DEPARTMENT
				if (checkFail == false) {
					for (Department check : u1.getDepartmentList()) {
						if (dName.getText().equalsIgnoreCase(check.getDepartmentName())) {
							checkHelp = true;
							break;
						}
					}
					if (!checkHelp) {
						JOptionPane.showMessageDialog(null,  
								"Department "+'"'+dName.getText()+'"'
								+" isn't a valid department",
								"Error Creating Campus Course",
								JOptionPane.ERROR_MESSAGE);
						checkFail = true;
					}
					checkHelp = false;
				}
//CREATE COURSE
				if (checkFail == false) {
					CampusCourse c1 = new CampusCourse();
					for (Department check : u1.getDepartmentList()) {
						if (dName.getText().equalsIgnoreCase(check.getDepartmentName())) {
							check.addCourse(c1);
						}
					}
					c1.setName(cName.getText());
					c1.setCourseNumber(Integer.parseInt(cNum.getText()));
					c1.setMaxCourseLimit(Integer.parseInt(maxStudents.getText()));
					c1.setCreditUnits(Integer.parseInt(credits.getText()));
					String[] aSchedule = schedule.getText().split(" ");
					for (String check : aSchedule) {
					c1.setSchedule(Integer.parseInt(check));
					
					}
					JOptionPane.showMessageDialog(null,  
							"Successfully added "+c1.getName()+" to University",
							"Success",
							JOptionPane.PLAIN_MESSAGE);
				}

			}
//ELSE IF ADD ONLINE COURSE--------------------------------------------------				
			else if (source.equals(adminsNewOnlineCourse)) {
//CREATE FIELDS
				  JTextField cName = new JTextField(5);
			      JTextField dName = new JTextField(5);
			      JTextField cNum = new JTextField(5);
			      JTextField credits = new JTextField(5);
			      Boolean checkFail = false;
			      Boolean checkHelp = false;
//ADD FIELDS TO LIST			      
			      Object[] fields = {
			    		  "Course Name:", cName,
			    		  "Department:", dName,
			    		  "Course #:", cNum,
			    		  "Credits:", credits
			      };
//OUTPUT THE FIELDS
			      JOptionPane.showConfirmDialog(null, fields,"Create New Online Course"
			    		  ,JOptionPane.OK_CANCEL_OPTION);
//CHECK FOR EMPTY ENTRIES			      
				for (Object check : fields) {
					if (check instanceof JTextField) {
					if (((JTextField) check).getText().length() == 0) {
						JOptionPane.showMessageDialog(null, 
								"User Input cannot be empty", 
								"Error Creating Online Course", 
								JOptionPane.ERROR_MESSAGE);
						checkFail = true;
						break;
						
					}
					}
				}
//CHECK FOR EXISTING DEPARTMENT
				if (checkFail == false) {
					for (Department check : u1.getDepartmentList()) {
						if (dName.getText().equalsIgnoreCase(check.getDepartmentName())) {
							checkHelp = true;
							break;
						}
					}
					if (!checkHelp) {
						JOptionPane.showMessageDialog(null,  
								"Department "+'"'+dName.getText()+'"'
								+" isn't a valid department",
								"Error Creating Online Course",
								JOptionPane.ERROR_MESSAGE);
						checkFail = true;
					}
					checkHelp = false;
				}
//CREATE COURSE
				if (checkFail == false) {
					OnlineCourse c1 = new OnlineCourse();
					for (Department check : u1.getDepartmentList()) {
						if (dName.getText().equalsIgnoreCase(check.getDepartmentName())) {
							check.addCourse(c1);
						}
					}
					c1.setName(cName.getText());
					c1.setCourseNumber(Integer.parseInt(cNum.getText()));
					c1.setCreditUnits(Integer.parseInt(credits.getText()));
					JOptionPane.showMessageDialog(null,  
							"Successfully added "+c1.getName()+" to University",
							"Success",
							JOptionPane.PLAIN_MESSAGE);
				}
				
			}
//ELSE NEW DEPARTMENT------------------------------------------------------
			else if (source.equals(adminsNewDepartment)) {
//CREATE FIELDS
			      JTextField dName = new JTextField(5);;
			      Boolean checkFail = false;
			      Boolean checkHelp = false;
//ADD FIELDS TO LIST			      
			      Object[] fields = {
			    		  "Department Name:", dName
			      };
//OUTPUT THE FIELDS
			      JOptionPane.showConfirmDialog(null, fields,"New Department"
			    		  ,JOptionPane.OK_CANCEL_OPTION);
//CHECK FOR EMPTY ENTRIES			      
				for (Object check : fields) {
					if (check instanceof JTextField) {
					if (((JTextField) check).getText().length() == 0) {
						JOptionPane.showMessageDialog(null, 
								"User Input cannot be empty", 
								"Error Adding Department to University", 
								JOptionPane.ERROR_MESSAGE);
						checkFail = true;
						break;
						
					}
					}
				}
//CHECK FOR EXISTING DEPARTMENT
				if (checkFail == false) {
					for (Department check : u1.getDepartmentList()) {
						if (dName.getText().equalsIgnoreCase(check.getDepartmentName())) {
							JOptionPane.showMessageDialog(null,  
									check.getDepartmentName()
									+" Department Already Exists",
									"Error Adding Department to University",
									JOptionPane.ERROR_MESSAGE);
							checkFail = true;
						}
					}

				}
//ADD DEPARTMENT
				if (checkFail == false) {
					Department d1 = new Department();
					d1.setDepartmentName(dName.getText().toUpperCase());
					u1.addDepartment(d1);
					JOptionPane.showMessageDialog(null,  
							dName.getText().toUpperCase()
							+" Department was added to University",
							"Success",
							JOptionPane.PLAIN_MESSAGE);
				}
			}
//ELSE ASSIGN COURSE CLASSROOM---------------------------------------------
			else if (source.equals(adminsAssignCourseClassroom)) {
//CREATE FIELDS
			      JTextField dName = new JTextField(5);
			      JTextField cNum = new JTextField(5);
			      JTextField room = new JTextField(5);
			      Boolean checkFail = false;
			      Boolean checkHelp = false;
//ADD FIELDS TO LIST			      
			      Object[] fields = {
			    		  "Course Department:", dName,
			    		  "Course #:", cNum,
			    		  "Room #:", room
			      };
//OUTPUT THE FIELDS
			      JOptionPane.showConfirmDialog(null, fields,"Create New Campus Course"
			    		  ,JOptionPane.OK_CANCEL_OPTION);
//CHECK FOR EMPTY ENTRIES			      
				for (Object check : fields) {
					if (check instanceof JTextField) {
					if (((JTextField) check).getText().length() == 0) {
						JOptionPane.showMessageDialog(null, 
								"User Input cannot be empty", 
								"Error Adding Campus Course Classroom", 
								JOptionPane.ERROR_MESSAGE);
						checkFail = true;
						break;
						
					}
					}
				}
//CHECK FOR EXISTING DEPARTMENT
				if (checkFail == false) {
					for (Department check : u1.getDepartmentList()) {
						if (dName.getText().equalsIgnoreCase(check.getDepartmentName())) {
							checkHelp = true;
							break;
						}
					}
					if (!checkHelp) {
						JOptionPane.showMessageDialog(null,  
								"Department "+'"'+dName.getText()+'"'
								+" isn't a valid department",
								"Error Assigning Campus Course Classroom",
								JOptionPane.ERROR_MESSAGE);
						checkFail = true;
					}
					checkHelp = false;
				}
				
//CHECK FOR ROOM NUMBER
				
				if (checkFail == false) {
					for (Classroom check : u1.getClassroomList()) {
						if (room.getText().equalsIgnoreCase(check.getRoomNumber())) {
							checkHelp = true;
							break;
						}
					}
					if (!checkHelp) {
						JOptionPane.showMessageDialog(null,  
								"Room "+'"'+room.getText()+'"'
								+" isn't a valid room",
								"Error Assigning Campus Course Classroom",
								JOptionPane.ERROR_MESSAGE);
						checkFail = true;
					}
					checkHelp = false;
				}

//CHECK FOR COURSE

				if (checkFail == false) {
					for (Department check : u1.getDepartmentList()) {
						for (CampusCourse check1 : check.getCampusCourseList()) {
							if (Integer.parseInt(cNum.getText())==check1.getCourseNumber()) {
								checkHelp = true;
								break;
							}
						
						}
						
					}
					if (!checkHelp) {
						JOptionPane.showMessageDialog(null,  
								"Course "+'"'+dName.getText()+cNum.getText()+'"'
								+" isn't a valid course",
								"Error Assigning Campus Course Classroom",
								JOptionPane.ERROR_MESSAGE);
						checkFail = true;
					}
					checkHelp = false;
				}

//DETECT TIMING CONFLICT
				if (checkFail == false) {
					
					ByteArrayOutputStream out1 = new ByteArrayOutputStream();
					PrintStream out = new PrintStream(out1);
					PrintStream old = System.out;
					System.setOut(out);
					for (Classroom check : u1.getClassroomList()) {
						for (Department check1 : u1.getDepartmentList()) {
							if (dName.getText().equalsIgnoreCase(check1.getDepartmentName())) {
							for (CampusCourse check2 : check1.getCampusCourseList()) {
								if ((Integer.parseInt(cNum.getText())==check2.getCourseNumber())
										&& room.getText().equalsIgnoreCase(check.getRoomNumber())) {
									if (check.detectConflict(check2)) {
										System.setOut(old);
										
										JOptionPane.showMessageDialog(null,  
												out1.toString(),
												"Error Assigning Campus Course Classroom",
												JOptionPane.ERROR_MESSAGE);
										checkFail = true;
										return;
									}
								}
							
							}
							}
						
						}
					}
					System.setOut(old);
				}

//ADD COURSE
				if (checkFail == false) {
					for (Department check : u1.getDepartmentList()) {
						if (dName.getText().equalsIgnoreCase(check.getDepartmentName())) {
							for (CampusCourse check2 : check.getCampusCourseList()) {
								if (Integer.parseInt(cNum.getText())==check2.getCourseNumber()) {
									for (Classroom check3 : u1.getClassroomList()) {
										if (room.getText().equalsIgnoreCase(check3.getRoomNumber())) {
											check2.setRoomAssigned(check3);
											JOptionPane.showMessageDialog(null,  
													"Success you have assigned "+dName.getText()
													+cNum.getText()+" to "+room.getText(),
													"Success",
													JOptionPane.PLAIN_MESSAGE);
											return;
										}
									}
								}
							}
						}
					}

				}
			}
//ELSE IF ASSIGN COURSE PROFESSOR-----------------------------
			else if (source.equals(adminsAssignCourseProfessor)) {
//CREATE FIELDS
				  JTextField pName = new JTextField(5);
			      JTextField dName = new JTextField(5);
			      JTextField cNum = new JTextField(5);
			      Boolean checkFail = false;
			      Boolean checkHelp = false;
//ADD FIELDS TO LIST			      
			      Object[] fields = {
			    		  "Professor Name:", pName,
			    		  "Department:", dName,
			    		  "Course #:", cNum
			      };
//OUTPUT THE FIELDS
			      JOptionPane.showConfirmDialog(null, fields,"Assign Professor to Course"
			    		  ,JOptionPane.OK_CANCEL_OPTION);
//CHECK FOR EMPTY ENTRIES			      
				for (Object check : fields) {
					if (check instanceof JTextField) {
					if (((JTextField) check).getText().length() == 0) {
						JOptionPane.showMessageDialog(null, 
								"User Input cannot be empty", 
								"User Input Error", 
								JOptionPane.ERROR_MESSAGE);
						checkFail = true;
						break;
						
					}
					}
				}				
//CHECK FOR EXISTING DEPARTMENT
				if (checkFail == false) {
					for (Department check : u1.getDepartmentList()) {
						if (dName.getText().equalsIgnoreCase(check.getDepartmentName())) {
							checkHelp = true;
							break;
						}
					}
					if (!checkHelp) {
						JOptionPane.showMessageDialog(null,  
								"Department "+dName.getText()
								+" doesn't exist",
								"Error",
								JOptionPane.PLAIN_MESSAGE);
						checkFail = true;
					}
					checkHelp = false;
				}
//CHECK FOR Professor
				if (checkFail == false) {
					for (Department check : u1.getDepartmentList()) {
						
							for (Professor check1 : check.getProfessorList()) {
								if (pName.getText().equalsIgnoreCase(check1.getName())) {
									checkHelp = true;
									break;
								}
					
						}
					}
					if (!checkHelp) {
						JOptionPane.showMessageDialog(null,  
								"Professor "+pName.getText()
								+" doesn't exist",
								"Error",
								JOptionPane.PLAIN_MESSAGE);
						checkFail = true;
					}
					checkHelp = false;
				}
//CHECK FOR Course
				if (checkFail == false) {
					for (Department check : u1.getDepartmentList()) {
						if (dName.getText().equalsIgnoreCase(check.getDepartmentName())) {
							for (OnlineCourse check1 : check.getOnlineCourseList()) {
								if (Integer.parseInt(cNum.getText()) == check1.getCourseNumber()) {
									checkHelp = true;
									break;
								}
							}
						}
					}
					if (!checkHelp) {
						JOptionPane.showMessageDialog(null,  
								"Online Course: "+dName.getText().toUpperCase()
								+cNum.getText().toString()
								+" doesn't exist",
								"Error",
								JOptionPane.PLAIN_MESSAGE);
						checkFail = true;
					}
					checkHelp = false;
				}
//CHECK FOR Professor Conflict
				if (checkFail == false) {
					ByteArrayOutputStream out1 = new ByteArrayOutputStream();
					PrintStream out = new PrintStream(out1);
					PrintStream old = System.out;
					System.setOut(out);
					for (Department check : u1.getDepartmentList()) {
						if (dName.getText().equalsIgnoreCase(check.getDepartmentName())) {
							for (Department check3 : u1.getDepartmentList()) {
							for (Professor check1 : check3.getProfessorList()) {
								if (pName.getText().equalsIgnoreCase(check1.getName())) {
									for (OnlineCourse check2 : check.getOnlineCourseList()) {
										if (Integer.parseInt(cNum.getText())==check2.getCourseNumber()) {
											
											if (check2.getProfessor()!= null) {	
											check1.addCourse(check2);
											JOptionPane.showMessageDialog(null,  
													out1.toString(),
													"Error",
													JOptionPane.PLAIN_MESSAGE);
											checkFail = true;
											System.setOut(old);
											return;
											}
											else {
												check1.addCourse(check2);
												JOptionPane.showMessageDialog(null,  
														"Professor "+check1.getName()+" has been assigned to the "
														+check.getDepartmentName()+check2.getCourseNumber()+" "
														+check2.getName()+" - Online Course",
														"Success",
														JOptionPane.PLAIN_MESSAGE);
											}
										}
									}
								}
							}
							}
						}
					}
					System.setOut(old);
				}

				
			}
		}
		

	}
}
