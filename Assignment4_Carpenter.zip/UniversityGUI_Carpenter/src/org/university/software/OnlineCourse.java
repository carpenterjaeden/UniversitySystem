package org.university.software;

import org.university.people.Student;

public class OnlineCourse extends Course{

	public boolean availableTo(Student aStudent) {
		if (aStudent.getEnrolledCredits()>=6)
			return true;
		else {
			
			return false;
		}
	}
}
