package org.university.software;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.*;
import org.university.hardware.*;


import org.university.hardware.Department;
import org.university.people.*;

public abstract class Course implements Serializable{
	protected String name;
	protected Department department;
	
	protected int courseNumber;
	protected ArrayList<Person> roster = new ArrayList<Person>();
	protected Professor professor;
	protected int creditUnits;
	
	Course(){
		this.professor = null;
	}
	





	public int getCreditUnits() {
		return creditUnits;
	}



	public void setCreditUnits(int creditUnits) {
		this.creditUnits = creditUnits;
	}






	public void setProfessor(Professor newProfessor) {
		this.professor = newProfessor;
	}
	public Professor getProfessor() {
		return this.professor;
	}
	
	public void setDepartment(Department newDepartment) {
		this.department = newDepartment;
	}
	public Department getDepartment() {
		return this.department;
	}
	
	public void setName(String newName) {
		this.name = newName;
	}
	public String getName() {
		return this.name;
	}
	

	
	public void setCourseNumber(int newCourseNumber) {
		this.courseNumber = newCourseNumber;
	}
	public int getCourseNumber() {
		return this.courseNumber;
	}
	
	public void addStudentToRoster(Person newStudent) {
		
		this.roster.add(newStudent);
	}
	public void removeStudentFromRoster(Person newStudent) {
		
		this.roster.remove(newStudent);
	}
	public ArrayList<Person> getStudentRoster(){
		return this.roster;
	}
	
	public abstract boolean availableTo(Student aStudent);
	public void printRoster() {
		for (Person p1 : this.roster) {
			System.out.println(p1.getName());
		}
	}
	
	

	

}
