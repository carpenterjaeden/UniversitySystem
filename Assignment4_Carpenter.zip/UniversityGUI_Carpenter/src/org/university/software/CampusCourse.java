package org.university.software;

import java.util.ArrayList;

import org.university.hardware.Classroom;
import org.university.people.Student;

public class CampusCourse extends Course {

	private Classroom room;
	private int MaxCourseLimit;
	private ArrayList<Integer> schedule = new ArrayList<Integer>();
	

	

	public int getMaxCourseLimit() {
		return MaxCourseLimit;
	}

	public void setMaxCourseLimit(int maxCourseLimit) {
		MaxCourseLimit = maxCourseLimit;
	}

	public boolean availableTo(Student aStudent) {
		if (this.roster.size()< MaxCourseLimit)
			return true;
		else {
			
			return false;
		}
	}
	
	public Classroom getRoomAssigned() {
		return room;
	}


	public void setRoomAssigned(Classroom room) {
		this.room = room;
		room.addToSchedule(this);
	}
	
	public void setSchedule(int newSchedule) {
		this.schedule.add(newSchedule);
}
	public ArrayList<Integer> getSchedule() {
		return this.schedule;
}
	
	public void printSchedule() {
	int print1, print2;
	String[] Week = {"Mon", "Tue", "Wed", "Thu", "Fri"};
	String[] Slot =  { "8:00am to 9:15am" ,
			 "9:30am to 10:45am" ,
			 "11:00am to 12:15pm" ,
			 "12:30pm to 1:45pm" ,
			 "2:00pm to 3:15pm" ,
			 "3:30pm to 4:45pm"};
	
	for (int check : this.schedule) {
		print1 = check / 100;
		print2 = check % 100;
		System.out.println(Week[print1-1] + " " + Slot[print2-1]+" "+this.room.getRoomNumber());
	}
	 
}
}
