package org.university.software;
import java.util.ArrayList;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
//import org.university.software.*;
import org.university.people.*;
import org.university.hardware.*;

public class University implements Serializable {

	private String name;
	public ArrayList<Department> departmentList = new ArrayList<Department>();
	public ArrayList<Classroom> classroomList = new ArrayList<Classroom>();
	
	
	public void setName(String newName) {
		this.name = newName;
	}
	public String getName() {
		return this.name;
	}
	

	public void addDepartment(Department newDepartment) {
		this.departmentList.add(newDepartment);

	}
	public ArrayList<Department> getDepartmentList(){
		return this.departmentList;
	}
	

	public ArrayList<Classroom> getClassroomList() {
		return classroomList;
	}
	public void addClassroom(Classroom classroom) {
		this.classroomList.add(classroom);
	}
	public void printCourseList() {
		

		for (Department d1 : departmentList) {
			System.out.println("The course list for department "+d1.getDepartmentName());
			for (Course c1 : d1.getCampusCourseList()) {
				System.out.println(d1.getDepartmentName()+c1.getCourseNumber()+" "+c1.getName());
			}
			
			for (Course c1 : d1.getOnlineCourseList()) {
				System.out.println(d1.getDepartmentName()+c1.getCourseNumber()+" "+c1.getName());
				
			}
			System.out.println("");
		}
		

		

		
	}
	public void printDepartmentList() {
		for (Department dl : departmentList) {
			System.out.println(dl.getDepartmentName());
		}
	}
	public void printClassroomList() {
		for (Classroom c1 : classroomList) {
			System.out.println(c1.getRoomNumber());
		}
	}
	public void printStudentList() {


		for (Department dl : departmentList) {
			for (Student sl : dl.getStudentList()) {
				System.out.println(sl.getName());
			}
		}

	}
	

	
	public void printProfessorList() {
		for (Department dl : departmentList) {
			System.out.println("The professor list for department " + dl.getDepartmentName());
			for (Professor pl : dl.getProfessorList()) {
				System.out.println(pl.getName());
			}
			System.out.println("");
		}
		
	}
	public void printStaffList() {
		for (Department dl : departmentList) {
			for (Staff pl : dl.getStaffList()) {
				System.out.println(pl.getName());
			}
		}
	}
	public static void saveData(University e) {
		FileOutputStream fileOut = null;
		ObjectOutputStream objOut = null;
		
		try 
		{
			fileOut = new FileOutputStream( "University.ser" );		//the Employee object makes its way to serial data in the file Employee.ser
			objOut = new ObjectOutputStream(fileOut);
			objOut.writeObject(e);
			objOut.close();
			fileOut.close();
	     }	
		
		catch(IOException i)
	    {
			i.printStackTrace();
	    }		
	}
	
	public static University loadData()
	{	
		FileInputStream fileIn = null;
		ObjectInputStream objIn = null;
		University emp=null;
			
		try
		{
			fileIn = new FileInputStream("University.ser");
			objIn = new ObjectInputStream(fileIn);
			emp = (University) objIn.readObject();
			objIn.close();
			fileIn.close();
		}
		catch(IOException i)
		{
			i.printStackTrace();
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}  
		return emp;
	}
	public void printClassroomSchedules() {
		for (Classroom c1 : classroomList) {
			System.out.println("The schedule for "
					+ "classroom " + c1.getRoomNumber());
			c1.printSchedule();
			System.out.println("");
		}
	}
	public void printDepartmentInfo() {
		for (Department d1 : departmentList) {
			System.out.println("Department " + d1.getDepartmentName() + '\n');
			System.out.println("Printing professor schedules:"+'\n');
			for (Professor p1 : d1.getProfessorList()) {
				System.out.println("The schedule for Prof. "+p1.getName()+":");
			    p1.printSchedule();
			    System.out.println("");
			}
			System.out.println("Printing student schedules:"+'\n');
			for (Student p1 : d1.getStudentList()) {
				System.out.println("The schedule for student "+p1.getName()+":");
			    p1.printSchedule();
			    System.out.println("");
			}
			System.out.println("Printing staff schedules:"+'\n');
			for (Staff p1 : d1.getStaffList()) {
				System.out.println("The schedule for employee "+p1.getName()+":");
			    p1.printSchedule();
			    System.out.println("");
			}
			for (Staff p1 : d1.getStaffList()) {
				System.out.println("Staff: "+p1.getName()+" earns "+p1.getMonthlyHours()*p1.getPayRate()
									+ " this month");
			}
			System.out.println('\n'+"The rosters for courses offered by "+d1.getDepartmentName()+'\n');
		    for (CampusCourse c1 : d1.getCampusCourseList()) {
		    	System.out.println("The roster for course "+d1.getDepartmentName()+c1.getCourseNumber());
		    	c1.printRoster();
		    	System.out.println("");
		    }
		    
		}
	}
	
	public void printAll() {
		System.out.println('\n'+"Department list:");
		this.printDepartmentList();
		System.out.println("");
		System.out.println("Classroom list:");
		this.printClassroomList();
		System.out.println("");
		this.printProfessorList();
		this.printCourseList();
		this.printClassroomSchedules();
		this.printDepartmentInfo();
		
	}
	
}
