package org.university.hardware;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import org.university.people.*;
import org.university.software.*;

public class Department implements Serializable{

	private String name;
	private ArrayList<Student> roster = new ArrayList<Student>();
	private ArrayList<CampusCourse> CampusCourseList = new ArrayList<CampusCourse>();
	private ArrayList<OnlineCourse> OnlineCourseList = new ArrayList<OnlineCourse>();
	private ArrayList<Professor> professors = new ArrayList<Professor>();
	private ArrayList<Staff> staff = new ArrayList<Staff>();

	public void addStaff(Staff newStaff) {
		this.staff.add(newStaff);
		newStaff.setDepartment(this);
	}
	public ArrayList<Staff> getStaffList(){
		return this.staff;
	}
	
	public void addProfessor(Professor newProfessor) {
		this.professors.add(newProfessor);
		newProfessor.setDepartment(this);
	}
	public ArrayList<Professor> getProfessorList(){
		return this.professors;
	}
	
	public void setDepartmentName(String newName) {
		this.name = newName;
	}
	public String getDepartmentName() {
		return this.name;
	}
	
	public void addStudent(Student newStudent) {
		this.roster.add(newStudent);
		newStudent.setDepartment(this);
	}
	public ArrayList<Student> getStudentList(){
		return this.roster;
	}
	
	public void addCourse(CampusCourse newCourse) {
		CampusCourseList.add(newCourse);
		newCourse.setDepartment(this);
		
	}
	public ArrayList<CampusCourse> getCampusCourseList(){
		return CampusCourseList;
	}
	
	public void addCourse(OnlineCourse newCourse) {
		OnlineCourseList.add(newCourse);
		newCourse.setDepartment(this);
		
	}
	public ArrayList<OnlineCourse> getOnlineCourseList(){
		return OnlineCourseList;
	}
	
	public void printStudentList() {
		for (Student print : roster) {
			System.out.println(print.getName());
		}
	}
	
	public void printProfessorList() {
		for (Professor print : professors) {
			System.out.println(print.getName());
		}
	}
	
	public void printCourseList() {
		for (CampusCourse print : CampusCourseList) {
			System.out.println(print.getDepartment().getDepartmentName()+print.getCourseNumber()+" "
					+print.getName());
		}
		for (OnlineCourse print : OnlineCourseList) {
			System.out.println(print.getDepartment().getDepartmentName()+print.getCourseNumber()+" "
					+print.getName());
		}
	}
	
}
