package org.university.hardware;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import org.university.software.*;
import java.util.*;

public class Classroom implements Serializable{
	private ArrayList<CampusCourse> schedule = new ArrayList<CampusCourse>();
	private String roomNumber;
	
	
	public boolean detectConflict(CampusCourse aCourse) {
		boolean test = false;
		String[] Week = {"Mon", "Tue", "Wed", "Thu", "Fri"};
		String[] Slot =  { "8:00am to 9:15am" ,
				 "9:30am to 10:45am" ,
				 "11:00am to 12:15pm" ,
				 "12:30pm to 1:45pm" ,
				 "2:00pm to 3:15pm" ,
				 "3:30pm to 4:45pm"};
		
		for (CampusCourse check : this.schedule) {
			for (int check1 : check.getSchedule()) {
				for (int check2 : aCourse.getSchedule()) {
					if (check2 == check1) {
						int print1 = check2 / 100;
						int print2 = check2 % 100;
						System.out.println(aCourse.getDepartment().getDepartmentName() +
						aCourse.getCourseNumber()+" conflicts with "
						+ check.getDepartment().getDepartmentName() +
						check.getCourseNumber() + ". Conflicting time slot " + Week[print1-1] + " " + Slot[print2-1]
						+ ". "+aCourse.getDepartment().getDepartmentName() +
						aCourse.getCourseNumber()+" course cannot be added to "+this.roomNumber+"'s Schedule.");
						return true;
					}
				}
			}
		}
		return test;
	}
	
	public String getRoomNumber() {
		return roomNumber;
	}



	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}



	public ArrayList<CampusCourse> getSchedule() {
		return schedule;
	}



	public void addToSchedule(CampusCourse add) {
		boolean check = detectConflict(add);
		if (!check) {
		this.schedule.add(add);
		}

	}



	public void printSchedule() {
		int print1, print2;
		String[] Week = {"Mon", "Tue", "Wed", "Thu", "Fri"};
		String[] Slot =  { "8:00am to 9:15am" ,
				 "9:30am to 10:45am" ,
				 "11:00am to 12:15pm" ,
				 "12:30pm to 1:45pm" ,
				 "2:00pm to 3:15pm" ,
				 "3:30pm to 4:45pm"};
		
		for (int i = 0;i < 6; i++) {
		for (int j=0;j<7;j++) {
		for (CampusCourse check : this.schedule) {
			
			for (int check1 : check.getSchedule()) {
				print1 = check1 / 100;
				print2 = check1 % 100;
				if (print1==i && print2 == j) {
				System.out.println(Week[print1-1] + " " + Slot[print2-1]+" "
						+ check.getDepartment().getDepartmentName()+
						check.getCourseNumber() + " "+
						check.getName());
				}
			}
		}
		 
	}
	}
	}
}
