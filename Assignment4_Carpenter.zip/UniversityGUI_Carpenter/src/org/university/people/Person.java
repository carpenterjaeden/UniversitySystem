package org.university.people;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import org.university.software.*;

import java.util.*;

import org.university.hardware.Department;

public abstract class Person implements Serializable{

		protected ArrayList<Integer> schedule = new ArrayList<Integer>();
		protected String name;
		protected ArrayList<CampusCourse> CampusCourseList = new ArrayList<CampusCourse>();
		protected ArrayList<OnlineCourse> OnlineCourseList = new ArrayList<OnlineCourse>();
		
		
		


	public ArrayList<Integer> getSchedule() {
			return schedule;
		}

		public void addSchedule(int schedule) {
			this.schedule.add(schedule);
		}

	public boolean detectConflict(CampusCourse aCourse){
		boolean test = false;
		String[] Week = {"Mon", "Tue", "Wed", "Thu", "Fri"};
		String[] Slot =  { "8:00am to 9:15am" ,
				 "9:30am to 10:45am" ,
				 "11:00am to 12:15pm" ,
				 "12:30pm to 1:45pm" ,
				 "2:00pm to 3:15pm" ,
				 "3:30pm to 4:45pm"};	
		
			for (CampusCourse check : this.CampusCourseList) {
				for (int check1 : check.getSchedule()) {
					for(int check2 : aCourse.getSchedule()) {
						if (check2 == check1) {
							int print1 = check2 / 100;
							int print2 = check2 % 100;
							
							System.out.println(aCourse.getDepartment().getDepartmentName() +
							aCourse.getCourseNumber()+" course cannot be added to "+this.name+"'s Schedule. "
							+ aCourse.getDepartment().getDepartmentName() +
							aCourse.getCourseNumber() + " conflicts with "
							+check.getDepartment().getDepartmentName() +
							check.getCourseNumber()+". Conflicting time slot is " + Week[print1-1] + " " + Slot[print2-1]
							+ ".");
							return true;
					}
					
					}
				}
				
			}
				
				return test;
		}
		
		public void setName(String newName) {
			this.name = newName;
		}
		public String getName() {
			return this.name;
		}
		

		
		public abstract void addCourse(CampusCourse aCourse);
		public abstract void addCourse(OnlineCourse aCourse);
		
		
		public ArrayList<CampusCourse> getCampusCourseList(){
			return CampusCourseList;
		}
		public ArrayList<OnlineCourse> getOnlineCourseList(){
			return OnlineCourseList;
		}
		
		public void printSchedule() {
			int print1, print2;
			String[] Week = {"Mon", "Tue", "Wed", "Thu", "Fri"};
			String[] Slot =  { "8:00am to 9:15am" ,
					 "9:30am to 10:45am" ,
					 "11:00am to 12:15pm" ,
					 "12:30pm to 1:45pm" ,
					 "2:00pm to 3:15pm" ,
					 "3:30pm to 4:45pm"};
			for (int i = 0;i < 6; i++) {
			for (int j=0;j<7;j++) {
			for (CampusCourse check : this.CampusCourseList) {
				for (int check1 : check.getSchedule()) {
					print1 = check1 / 100;
					print2 = check1 % 100;
					if (print1==i && print2 == j) {
					System.out.println(Week[print1-1] + " " + Slot[print2-1]+" "
							+ check.getDepartment().getDepartmentName()+
							check.getCourseNumber() + " "+
							check.getName());
					}
				}
			}
			}
			}
			for (OnlineCourse check : this.OnlineCourseList) {
				System.out.println(check.getDepartment().getDepartmentName()
						+ check.getCourseNumber()+ " "+check.getName());
			
			}
		}
		
	}

