package org.university.people;

public abstract class Employee extends Person{

	public abstract double earns();
	public abstract void raise(double percent);
}
