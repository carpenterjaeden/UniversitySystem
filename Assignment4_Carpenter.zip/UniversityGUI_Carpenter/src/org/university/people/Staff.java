package org.university.people;

import org.university.hardware.Department;
import org.university.software.*;

public class Staff extends Employee{
	private int hoursWorked;
	private double payRate;
	private Department department;
	private int tuitionFee;
	

	
	
	
	public int getMonthlyHours() {
		return hoursWorked;
	}



	public void setMonthlyHours(int hoursWorked) {
		this.hoursWorked = hoursWorked;
	}



	public double getPayRate() {
		return payRate;
	}



	public void setPayRate(double payRate) {
		this.payRate = payRate;
	}



	public Department getDepartment() {
		return department;
	}



	public void setDepartment(Department department) {
		this.department = department;
	}



	public int getTuitionFee() {
		int ccredits = 0;
		tuitionFee = 0;
		for (CampusCourse check : this.CampusCourseList) {
			ccredits += check.getCreditUnits();
		}
		tuitionFee += ccredits * 300;
		for (OnlineCourse check1 : this.OnlineCourseList) {
			if (check1.getCreditUnits() == 3) {
				tuitionFee += 2000;
			}
			else if (check1.getCreditUnits() == 4) {
				tuitionFee += 3000;
			}
			else {
				System.out.println("Error in staff calculateTuitionFee");
			}
			
		}
		return tuitionFee;
	}
	
	
	public double earns() {
		return (hoursWorked*payRate);
	}
	
	public void raise(double percent) {
		payRate = payRate + payRate*percent*.01;
	}
	
	public void addCourse(CampusCourse cCourse){
		if (this.CampusCourseList.size() == 0 && this.OnlineCourseList.size() == 0) {
			this.CampusCourseList.add(cCourse);
			cCourse.addStudentToRoster(this);
		}
		else {
			if (this.CampusCourseList.size()!= 0) {
			System.out.print(this.CampusCourseList.get(0).getDepartment().getDepartmentName()
					+this.CampusCourseList.get(0).getCourseNumber());
			}
			else {
				System.out.print(this.OnlineCourseList.get(0).getDepartment().getDepartmentName()
						+this.OnlineCourseList.get(0).getCourseNumber());
			}
			System.out.println(" is removed from "+this.name+"'s schedule(Staff can only take one class"
					+ " at a time). "+cCourse.getDepartment().getDepartmentName()+cCourse.getCourseNumber()+
					" has been added to "+this.name+"'s Schedule.");
			this.CampusCourseList.clear();
			this.OnlineCourseList.clear();
			this.CampusCourseList.add(cCourse);
		}
	}
	public void addCourse(OnlineCourse oCourse){
		if (this.CampusCourseList.size() == 0 && this.OnlineCourseList.size() == 0) {
			this.OnlineCourseList.add(oCourse);
			oCourse.addStudentToRoster(this);
		}
		else {
				if (this.CampusCourseList.size()!= 0) {
				System.out.print(this.CampusCourseList.get(0).getDepartment().getDepartmentName()
						+this.CampusCourseList.get(0).getCourseNumber());
				}
				else {
					System.out.print(this.OnlineCourseList.get(0).getDepartment().getDepartmentName()
							+this.OnlineCourseList.get(0).getCourseNumber());
				}
				System.out.println(" is removed from "+this.name+"'s schedule(Staff can only take one class"
						+ " at a time). "+oCourse.getDepartment().getDepartmentName()+oCourse.getCourseNumber()+
						" has been added to "+this.name+"'s Schedule.");
			this.CampusCourseList.clear();
			this.OnlineCourseList.clear();
			this.OnlineCourseList.add(oCourse);
		}
	}
}
