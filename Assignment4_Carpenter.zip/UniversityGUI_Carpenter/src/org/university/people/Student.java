package org.university.people;
import org.university.software.*;

import java.util.*;

import org.university.hardware.Department;

public class Student extends Person{

	private Department department;
	private int completedUnits, requiredCredits, enrolledCredits, tuitionFee;
	
	
	public Student() {
		enrolledCredits = 0;
	}
	
	public void addCourse(CampusCourse aCourse) {
if (this.detectConflict(aCourse)){
			
			return;
		}
if (aCourse.availableTo(this)) {
for (int check : aCourse.getSchedule()) {
	this.schedule.add(check);
}

		this.CampusCourseList.add(aCourse);
		enrolledCredits+=aCourse.getCreditUnits();
		aCourse.addStudentToRoster(this);
}
else{
	System.out.println(this.getName()+" can't add Campus Course "+aCourse.getDepartment().getDepartmentName()
			+aCourse.getCourseNumber()+" "+aCourse.getName()+". Because this Campus course has enough"
					+ " student.");
	return;
}
	}
	
	public void addCourse(OnlineCourse aCourse) {
		
		if (aCourse.availableTo(this)) {
			this.OnlineCourseList.add(aCourse);
			enrolledCredits+=aCourse.getCreditUnits();
			aCourse.addStudentToRoster(this);
		}
		else {
			System.out.println("Student "+this.name+" has only "+this.enrolledCredits
					+" on campus credits enrolled. Should have at least 6 credits registered"
					+ " before registering online courses.");
			System.out.println(this.name+" can't add online Course "+aCourse.getDepartment().getDepartmentName()+aCourse.getCourseNumber()
					+" "+aCourse.getName()+". Because this student doesn't have enough Campus course credit.");
			return;
		}
			
	}
	
	
public int getCompletedUnits() {
		return completedUnits;
	}

	public void setCompletedUnits(int completedUnits) {
		this.completedUnits = completedUnits;
	}

	public int getRequiredCredits() {
		return requiredCredits;
	}

	public void setRequiredCredits(int requiredCredits) {
		this.requiredCredits = requiredCredits;
	}
	
	public int requiredToGraduate() {
		return requiredCredits - completedUnits-enrolledCredits;
	}
	

public int getEnrolledCredits() {

		return enrolledCredits;
}

	public int getTuitionFee() {
		int ccredits = 0;
		tuitionFee = 0;
		for (CampusCourse check : this.CampusCourseList) {
			ccredits += check.getCreditUnits();
		}
		tuitionFee += ccredits * 300;
		for (OnlineCourse check1 : this.OnlineCourseList) {
			if (check1.getCreditUnits() == 3) {
				tuitionFee += 2000;
			}
			else if (check1.getCreditUnits() == 4) {
				tuitionFee += 3000;
			}
			else {
				System.out.println("Error in staff calculateTuitionFee");
			}
			
		}
		return tuitionFee;
		
	}
	
	
	public void setDepartment(Department newDepartment) {
		this.department = newDepartment;
	}
	public Department getDepartment() {
		return this.department;
	}

	
	 public void dropCourse(CampusCourse cCourse){
		 
		 boolean checkCourse = false; //will be set to true if the student is in the course
		 for (CampusCourse check : this.CampusCourseList) {
			 if (check == cCourse) {
				 checkCourse = true;
			 }

		 }
		 if (!checkCourse) {
		 System.out.println("The course " +  cCourse.getDepartment().getDepartmentName()
		 + cCourse.getCourseNumber() + " could not be dropped because " + this.name +
		 " is not enrolled in " + cCourse.getDepartment().getDepartmentName()
		 + cCourse.getCourseNumber() + ".");
		 return;
		 }
		

		 else {
			 if(this.OnlineCourseList.size()!=0){
				int onlinecredits = 0;
				for (OnlineCourse check1 : this.OnlineCourseList) {
					onlinecredits+=check1.getCreditUnits();
				}
				if (enrolledCredits-onlinecredits-cCourse.getCreditUnits() < 6) {
				 System.out.println(this.name+" can't drop this CampusCourse, because this student"
				 		+ " doesn't have enough campus course credit to hold the online course");
				 return;
			 }}
				
						this.CampusCourseList.remove(cCourse);
						enrolledCredits -= cCourse.getCreditUnits();
						cCourse.removeStudentFromRoster(this);
						 for (int check1 : cCourse.getSchedule()) {
								this.schedule.remove(Integer.valueOf(check1));
							}
						return;
					
				
		 }
		 
	 }

	 public void dropCourse(OnlineCourse oCourse){
		 boolean checkCourse = false; //will be set to true if the student is in the course
		 for (OnlineCourse check : this.OnlineCourseList) {
			 if (check == oCourse) {
				 checkCourse = true;
			 }

		 }
		 if (!checkCourse) {
		 System.out.println("The course " +  oCourse.getDepartment().getDepartmentName()
		 + oCourse.getCourseNumber() + " could not be dropped because " + this.name +
		 " is not enrolled in " + oCourse.getDepartment().getDepartmentName()
		 + oCourse.getCourseNumber() + ".");
		 return;
		 }
		 this.OnlineCourseList.remove(oCourse);
		 oCourse.removeStudentFromRoster(this);
		 enrolledCredits -= oCourse.getCreditUnits();
	 }

	
}
