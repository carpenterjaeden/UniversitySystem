package org.university.people;
import java.util.*;
import org.university.software.*;


import org.university.hardware.Department;

public class Professor extends Employee {
	private Department department;
	private double salary;
	
	

	
	
public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}


	
	
	public void addCourse(CampusCourse aCourse) {
		if (this.detectConflict(aCourse)){
			
			return;
		}
		if (aCourse.getProfessor() != null) {
			
			System.out.println("The professor "+this.name+ " cannot be assigned to this campus course"
					+ " because professor " + aCourse.getProfessor().getName()
			 + " is already assigned to the course "+ aCourse.getName()+".");
			return;
		}
		for (int check : aCourse.getSchedule()) {
			this.schedule.add(check);
		}
		CampusCourseList.add(aCourse);
		aCourse.setProfessor(this);
		
	}
	public void addCourse(OnlineCourse aCourse) {
		
		if (aCourse.getProfessor() != null) {
			
			System.out.println("The professor cannot be assigned to this online course"
					+ " because professor " + aCourse.getProfessor().getName()
			 + " is already assigned to the online course "+ aCourse.getName()+".");
			return;
		}
		OnlineCourseList.add(aCourse);
		aCourse.setProfessor(this);
		
	}


	
	public void raise(double percent) {
		salary = salary + salary * percent*.01;
		
	}
	public double earns() {
		return this.salary/26;
	}
		 
}
